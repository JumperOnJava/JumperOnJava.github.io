# XorDevs Default Shaderpack
Minecraft's default shaders, recreated for Optifine. I put this together so that it is easier for others to make their own shaderpacks from this starting point.

You can do whatever you want with this code! Credit is not necessary, but it's always appreciated!
You can find more information about shaders in Optfine here:
https://github.com/sp614x/optifine/blob/master/OptiFineDoc/doc/shaders.txt
